﻿export * from './register.component';

