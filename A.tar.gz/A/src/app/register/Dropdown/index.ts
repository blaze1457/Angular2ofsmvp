export class motherlang{
    constructor(
        private name: string){ }
}

export class caste{
    constructor(
        private name: string){ }
}

export class education{
    constructor(
        private name: string){ }
}

export class religion{
    constructor(
        private name: string) {}
}
export class marstatus{
    constructor(
        private name: string
    ){}
}

export class employee{
    constructor(
        private name: string
    ) {}
}

export class residency{
    constructor( 
        private name :string
    ) {}
}