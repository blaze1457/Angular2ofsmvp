import { Component, NgModule } from '@angular/core'
import { BrowserModule } from '@angular/platform-browser'
import { motherlang, caste, education, religion, marstatus, employee, residency } from '../Dropdown/index'

// MotherLanguage
@Component({
  selector: 'motherlang-list',
  templateUrl: './dropdown.html',
  styleUrls : ['./dropdownstyle.css']
})
export class motherlangListComponent {
  selectedCountry: motherlang = new motherlang('Tamil');
  motherlangs = ["Tamil", "English", "Hindi", "Urdu", "Kannada", "Telugu", "Malayalam", "Oriya", "Marathi", "Bengali", "Assamese", "Rajasthani", "Manipuri", "Others"];
}
//Caste
@Component({
  selector: 'caste-list',
  templateUrl: './caste.html',
  styleUrls : ['./dropdownstyle.css']
})
export class casteListComponent {
  selectedCountry: caste = new caste('Tamil');
  castes = ["Any", "Caste-No-Bar", "gnikula-Kshatriya", "Arya Vysya", "Balija", "Besta", "Brahmin", "Chettiar", "Devanga", "Gandla", "Gapublic", "Gowda", "Intercaste", "Kalinga", "Kamma", "Kapu", "Kshatriya", "Kummari", "Kuruba", "Lingayath", "Mannuru Kapu", "Madiga", "Mahendra", "Mala", "Maratha", "Meru Darji", "Mudaliyar", "Mudiraj", "Nadar", "Nai", "Naidu", "Padmasali", "Patnaick", "Rajaka", "Rajput", "Reddy", "SC", "Telaga", "Tribe", "Uppara", "Vaddera", "Vaishnava", "Valmiki", "Vanjara", "Vokkaliga", "Velama", "Viswabrahmin", "Yadava", "Other"];
}

//Education
@Component({
  selector: 'education-list',
  templateUrl: './education.html',
  styleUrls : ['./dropdownstyle.css']
})
export class educationListComponent {
  selectedCountry: education = new education('Tamil');
  educations = ["Any", "Bachelors-Engineering-Computers", "Masters-Engineering-Computers", "Bachelors-Arts-Science-Commerce-Others", "Masters-Arts-Science-Commerce-Others", "Management-BBA-MBA-Others", "Medicine-General-Dental-Surgeon-Others", "Legal-BL-ML-LLB-LLM-Others", "Service-IAS-IPS-Others", "Ph-Diploma", "Higher-Secondary-Secondary"];}

// Religion
@Component({
  selector: 'religion-list',
  templateUrl: './religion.html',
  styleUrls : ['./dropdownstyle.css']
})
export class religionListComponent {
  selectedCountry: religion = new religion('Tamil');
  religions = ["Hindu", "Muslim", "Christian", "Sikh", "Jain", "Parsi", "Buddhist", "InterReligion", "NoReligion"];
}

//Martial Status
@Component({
  selector: 'marstatus-list',
  templateUrl: './marstatus.html',
  styleUrls : ['./dropdownstyle.css']
})
export class marstatusListComponent {
  selectedCountry: marstatus = new marstatus('Tamil');
  marstatuss = ["Unmarried","Widow-Widower","Divorce","Separated"];
}

// Employement
@Component({
  selector: 'employee-list',
  templateUrl: './employee.html',
  styleUrls : ['./dropdownstyle.css']
})
export class employeeListComponent {
  selectedCountry: employee = new employee('Tamil');
  employees = ["Government", "Private", "Business", "Defence", "Not-Working"];
}

//Residency
@Component({
  selector: 'residency-list',
  templateUrl: './residency.html',
  styleUrls : ['./dropdownstyle.css']
})
export class residencyListComponent {
  selectedCountry: residency = new residency('Tamil');
  residencys = ["Citizen", "Permanent-Resident", "Work-Permit", "Student-Visa", "Temporary-Visa"];
} 