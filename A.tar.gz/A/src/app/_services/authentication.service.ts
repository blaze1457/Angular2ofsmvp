﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

@Injectable()
export class AuthenticationService {
    constructor(private http: Http,
                private router: Router) { }

    login(user_Id: string, password: string) {
        return this.http.post('http://localhost:8080/HibernateWebApp/rest/user/auth', JSON.stringify({ username: user_Id, password: password }))
            .map((response: Response) => {
                // login successful if there's a jwt token in the response
                let user = response.json();
                if ((user && user.token) && (response.status == 200)) {
                    console.log(user);
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    this.router.navigate(['/home']);
                }
            });
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
    }
}