﻿export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    Dob: Date;
    Pob: string;
    occupation: string;
    city: string;
    state: string;
    country: string;
    email: string;
    gender: string;
    annualincome: number;
    



}